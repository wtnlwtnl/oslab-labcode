#ifndef __KERN_SCHEDULE_SCHED_H__  // 头文件保护宏开始，防止重复包含
#define __KERN_SCHEDULE_SCHED_H__  // 定义头文件保护宏

#include <defs.h>       // 包含基本类型定义（如uint32_t等）
#include <list.h>       // 包含双向链表数据结构（用于RR算法）
#include <skew_heap.h>  // 包含斜堆数据结构（用于Stride算法）

#define MAX_TIME_SLICE 5  // 定义进程的最大时间片为5个时钟中断

struct proc_struct;  // 进程控制块结构体的前置声明，避免循环依赖

struct run_queue;  // 运行队列结构体的前置声明

// 调度类的引入借鉴自Linux，使得核心调度器具有很强的可扩展性。
// 这些类（调度器模块）封装了调度策略。
struct sched_class  // 调度类结构体，定义了调度算法的统一接口
{
    // 调度类的名称
    const char *name;  // 调度算法的名称字符串（如"RR_scheduler"）
    // 初始化运行队列
    void (*init)(struct run_queue *rq);  // 函数指针：初始化运行队列的函数
    // 将进程加入运行队列，此函数必须在持有rq_lock锁的情况下调用
    void (*enqueue)(struct run_queue *rq, struct proc_struct *proc);  // 函数指针：将进程插入就绪队列
    // 将进程从运行队列移除，此函数必须在持有rq_lock锁的情况下调用
    void (*dequeue)(struct run_queue *rq, struct proc_struct *proc);  // 函数指针：将进程从就绪队列移除
    // 选择下一个可运行的任务
    struct proc_struct *(*pick_next)(struct run_queue *rq);  // 函数指针：选择下一个要运行的进程
    // 时钟中断的处理函数
    void (*proc_tick)(struct run_queue *rq, struct proc_struct *proc);  // 函数指针：每个时钟中断调用，更新时间片
    /* 为未来的SMP（对称多处理器）支持预留
     *  负载均衡
     *     void (*load_balance)(struct rq* rq);
     *  从此运行队列获取一些进程，用于负载均衡，
     *  返回值是获取到的进程数量
     *  int (*get_proc)(struct rq* rq, struct proc* procs_moved[]);
     */
};

struct run_queue  // 运行队列结构体，管理所有就绪进程
{
    list_entry_t run_list;  // 双向链表头，用于RR算法串联所有就绪进程
    unsigned int proc_num;  // 就绪队列中的进程数量
    int max_time_slice;     // 进程的最大时间片大小
    // For LAB6 ONLY
    skew_heap_entry_t *lab6_run_pool;  // 斜堆的根节点指针，用于Stride算法
};

void sched_init(void);  // 初始化调度器，绑定具体的调度算法
void wakeup_proc(struct proc_struct *proc);  // 唤醒进程，将其状态设为RUNNABLE并加入就绪队列
void schedule(void);  // 核心调度函数，选择下一个进程并切换上下文
void sched_class_proc_tick(struct proc_struct *proc);  // 时钟中断时调用，处理当前进程的时间片更新
#endif /* !__KERN_SCHEDULE_SCHED_H__ */  // 头文件保护宏结束