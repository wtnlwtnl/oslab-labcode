/*
     这个文件实现了斜堆（Skew Heap）数据结构，它是一种特殊的优先队列。

     核心作用
     在Stride调度算法中，需要快速找到pass值最小的进程。斜堆提供了：
          O(log n) 的插入操作
          O(log n) 的删除操作
          O(1) 的查找最小值（堆顶就是最小值）
     为什么叫"斜堆"？
          它是堆：满足堆的性质（父节点≤子节点）
          它是斜的：每次合并时会交换左右子树，不像普通堆那么"平衡"
*/

#ifndef __LIBS_SKEW_HEAP_H__  // 头文件保护宏开始，防止重复包含
#define __LIBS_SKEW_HEAP_H__  // 定义头文件保护宏

struct skew_heap_entry {  // 斜堆节点结构体定义
     struct skew_heap_entry *parent, *left, *right;  // 父节点、左子节点、右子节点指针
};

typedef struct skew_heap_entry skew_heap_entry_t;  // 定义类型别名，简化使用

typedef int(*compare_f)(void *a, void *b);  // 定义比较函数指针类型，返回-1表示a<b，0表示a==b，1表示a>b

static inline void skew_heap_init(skew_heap_entry_t *a) __attribute__((always_inline));  // 初始化节点函数声明，强制内联
static inline skew_heap_entry_t *skew_heap_merge(  // 合并两个堆的函数声明
     skew_heap_entry_t *a, skew_heap_entry_t *b,  // 参数：两个要合并的堆的根节点
     compare_f comp);  // 参数：比较函数
static inline skew_heap_entry_t *skew_heap_insert(  // 插入节点函数声明，强制内联
     skew_heap_entry_t *a, skew_heap_entry_t *b,  // 参数：堆a和要插入的节点b
     compare_f comp) __attribute__((always_inline));  // 参数：比较函数，强制内联
static inline skew_heap_entry_t *skew_heap_remove(  // 删除节点函数声明，强制内联
     skew_heap_entry_t *a, skew_heap_entry_t *b,  // 参数：堆a和要删除的节点b
     compare_f comp) __attribute__((always_inline));  // 参数：比较函数，强制内联

static inline void  // 内联函数定义开始
skew_heap_init(skew_heap_entry_t *a)  // 初始化节点函数，将节点变成独立节点
{
     a->left = a->right = a->parent = NULL;  // 将左右子节点和父节点指针都设为NULL
}

static inline skew_heap_entry_t *  // 内联函数定义开始，返回合并后堆的根节点
skew_heap_merge(skew_heap_entry_t *a, skew_heap_entry_t *b,  // 合并函数，参数为两个堆的根节点
                compare_f comp)  // 比较函数参数
{
     if (a == NULL) return b;  // 如果a为空，返回b（递归终止条件1）
     else if (b == NULL) return a;  // 如果b为空，返回a（递归终止条件2）
     
     skew_heap_entry_t *l, *r;  // 定义临时指针l和r，用于交换左右子树
     if (comp(a, b) == -1)  // 如果a小于b（a的值更小）
     {
          r = a->left;  // 保存a的左子树到r
          l = skew_heap_merge(a->right, b, comp);  // 递归合并a的右子树和b，结果存到l
          
          a->left = l;  // 将合并结果设为a的左子树（交换：原右子树变左子树）
          a->right = r;  // 将原左子树设为a的右子树（交换：原左子树变右子树）
          if (l) l->parent = a;  // 如果l不为空，更新l的父节点为a

          return a;  // 返回a作为新的根节点
     }
     else  // 如果b小于等于a
     {
          r = b->left;  // 保存b的左子树到r
          l = skew_heap_merge(a, b->right, comp);  // 递归合并a和b的右子树，结果存到l
          
          b->left = l;  // 将合并结果设为b的左子树（交换）
          b->right = r;  // 将原左子树设为b的右子树（交换）
          if (l) l->parent = b;  // 如果l不为空，更新l的父节点为b

          return b;  // 返回b作为新的根节点
     }
}

static inline skew_heap_entry_t *  // 内联函数定义开始，返回插入后堆的根节点
skew_heap_insert(skew_heap_entry_t *a, skew_heap_entry_t *b,  // 插入函数，a是原堆，b是新节点
                 compare_f comp)  // 比较函数参数
{
     skew_heap_init(b);  // 初始化新节点b，清空其左右子树和父节点指针
     return skew_heap_merge(a, b, comp);  // 将b作为单节点堆与a合并，返回新根
}

static inline skew_heap_entry_t *  // 内联函数定义开始，返回删除后堆的根节点
skew_heap_remove(skew_heap_entry_t *a, skew_heap_entry_t *b,  // 删除函数，a是堆根，b是要删除的节点
                 compare_f comp)  // 比较函数参数
{
     skew_heap_entry_t *p   = b->parent;  // 保存b的父节点指针
     skew_heap_entry_t *rep = skew_heap_merge(b->left, b->right, comp);  // 合并b的左右子树，得到替代子树
     if (rep) rep->parent = p;  // 如果替代子树不为空，更新其父节点为p
     
     if (p)  // 如果b不是根节点（有父节点）
     {
          if (p->left == b)  // 如果b是父节点的左孩子
               p->left = rep;  // 用替代子树替换父节点的左孩子
          else p->right = rep;  // 否则b是右孩子，用替代子树替换父节点的右孩子
          return a;  // 返回原根节点a（根没有改变）
     }
     else return rep;  // b是根节点，返回替代子树作为新根
}

#endif    /* !__LIBS_SKEW_HEAP_H__ */  // 头文件保护宏结束