# 调度算法的切换机制分析

## 问题

分析如果要添加一个新的调度算法（如 Stride），需要修改哪些代码？并解释为什么当前的设计使得切换调度算法变得容易。

---

## 一、添加新调度算法的完整步骤

以添加 **Stride 调度算法** 为例，需要修改以下 4 个地方：

### 步骤 1：创建新的调度算法实现文件

在 `kern/schedule/` 目录下创建 `default_sched_stride.c`：

```c
#include <defs.h>
#include <list.h>
#include <proc.h>
#include <assert.h>
#include <default_sched.h>

#define BIG_STRIDE 0x7FFFFFFF  // 定义大步长常量

// 比较函数（用于斜堆）
static int proc_stride_comp_f(void *a, void *b) {
    struct proc_struct *p = le2proc(a, lab6_run_pool);
    struct proc_struct *q = le2proc(b, lab6_run_pool);
    int32_t c = p->lab6_stride - q->lab6_stride;
    return (c > 0) ? 1 : ((c == 0) ? 0 : -1);
}

// ① 初始化函数
static void stride_init(struct run_queue *rq) {
    list_init(&(rq->run_list));
    rq->lab6_run_pool = NULL;  // 斜堆初始化为空
    rq->proc_num = 0;
}

// ② 入队函数
static void stride_enqueue(struct run_queue *rq, struct proc_struct *proc) {
    rq->lab6_run_pool = skew_heap_insert(rq->lab6_run_pool, 
                                          &(proc->lab6_run_pool), 
                                          proc_stride_comp_f);
    if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {
        proc->time_slice = rq->max_time_slice;
    }
    proc->rq = rq;
    rq->proc_num++;
}

// ③ 出队函数
static void stride_dequeue(struct run_queue *rq, struct proc_struct *proc) {
    rq->lab6_run_pool = skew_heap_remove(rq->lab6_run_pool, 
                                          &(proc->lab6_run_pool), 
                                          proc_stride_comp_f);
    rq->proc_num--;
}

// ④ 选择下一个进程
static struct proc_struct *stride_pick_next(struct run_queue *rq) {
    if (rq->lab6_run_pool == NULL) return NULL;
    struct proc_struct *p = le2proc(rq->lab6_run_pool, lab6_run_pool);
    // 更新 stride 值
    if (p->lab6_priority == 0) {
        p->lab6_stride += BIG_STRIDE;
    } else {
        p->lab6_stride += BIG_STRIDE / p->lab6_priority;
    }
    return p;
}

// ⑤ 时钟中断处理
static void stride_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
    if (proc->time_slice > 0) {
        proc->time_slice--;
    }
    if (proc->time_slice == 0) {
        proc->need_resched = 1;
    }
}

// ★ 关键：定义调度类实例
struct sched_class stride_sched_class = {
    .name = "stride_scheduler",
    .init = stride_init,
    .enqueue = stride_enqueue,
    .dequeue = stride_dequeue,
    .pick_next = stride_pick_next,
    .proc_tick = stride_proc_tick,
};
```

### 步骤 2：在头文件中声明调度类

修改 `kern/schedule/default_sched.h`，添加外部声明：

```c
#ifndef __KERN_SCHEDULE_SCHED_RR_H__
#define __KERN_SCHEDULE_SCHED_RR_H__

#include <sched.h>

extern struct sched_class default_sched_class;   // RR 调度器
extern struct sched_class stride_sched_class;    // ★ 新增：Stride 调度器

#endif
```

### 步骤 3：修改 `sched_init()` 绑定新算法

修改 `kern/schedule/sched.c` 中的 `sched_init()` 函数：

```c
void sched_init(void) {
    list_init(&timer_list);

    // 修改这一行，切换到 Stride 调度器
    // sched_class = &default_sched_class;  // 原来的 RR
    sched_class = &stride_sched_class;      // ★ 切换到 Stride

    rq = &__rq;
    rq->max_time_slice = MAX_TIME_SLICE;
    sched_class->init(rq);

    cprintf("sched class: %s\n", sched_class->name);
}
```

### 步骤 4：确保新文件被编译（自动完成）

由于 Makefile 中配置了：

```makefile
KSRCDIR += kern/schedule
```

所有 `kern/schedule/` 目录下的 `.c` 文件都会被自动编译，无需手动修改 Makefile。

---

## 二、需要修改的文件汇总

| 序号 | 文件 | 修改内容 | 是否必须 |
|------|------|----------|----------|
| 1 | `kern/schedule/default_sched_stride.c` | **新建**：实现 5 个调度类函数 | ✅ 必须 |
| 2 | `kern/schedule/default_sched.h` | 添加 `extern struct sched_class stride_sched_class;` | ✅ 必须 |
| 3 | `kern/schedule/sched.c` | 修改 `sched_class = &stride_sched_class;` | ✅ 必须 |
| 4 | `Makefile` | 无需修改（自动编译） | ❌ 不需要 |
| 5 | `kern/schedule/sched.h` | 无需修改（接口已定义） | ❌ 不需要 |
| 6 | `kern/trap/trap.c` | 无需修改（通过接口调用） | ❌ 不需要 |

**核心结论：只需要修改 3 个文件，其中关键切换只需改 1 行代码！**

---

## 三、为什么当前设计使切换变得容易？

### 1. 面向接口编程（策略模式）

```c
struct sched_class {
    const char *name;
    void (*init)(struct run_queue *rq);
    void (*enqueue)(struct run_queue *rq, struct proc_struct *proc);
    void (*dequeue)(struct run_queue *rq, struct proc_struct *proc);
    struct proc_struct *(*pick_next)(struct run_queue *rq);
    void (*proc_tick)(struct run_queue *rq, struct proc_struct *proc);
};
```

**好处**：定义了统一的接口，所有调度算法都必须实现这 5 个函数。框架代码只调用接口，不关心具体实现。

### 2. 函数指针实现多态

```c
// 框架代码（不变）
sched_class->enqueue(rq, proc);
sched_class->pick_next(rq);

// 切换算法（只改指针指向）
sched_class = &default_sched_class;   // RR
sched_class = &stride_sched_class;    // Stride
sched_class = &fifo_sched_class;      // FIFO
```

**好处**：通过改变指针指向，就能切换整个调度行为，无需修改调用处的代码。

### 3. 机制与策略分离

```
┌─────────────────────────────────────────────────────────────┐
│                      机制层（不变）                          │
│  sched.c: schedule(), wakeup_proc(), sched_class_proc_tick()│
│  trap.c: 中断处理、need_resched 检查                        │
└─────────────────────────────────────────────────────────────┘
                           │
                           │ 通过 sched_class 指针调用
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      策略层（可替换）                        │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐│
│  │    RR     │  │  Stride   │  │   FIFO    │  │    SJF    ││
│  │ (链表)    │  │ (斜堆)    │  │ (链表)    │  │ (链表)    ││
│  └───────────┘  └───────────┘  └───────────┘  └───────────┘│
└─────────────────────────────────────────────────────────────┘
```

**好处**：
- 机制层负责"何时调度"、"如何切换上下文"
- 策略层负责"选谁调度"
- 两者互不干扰，可以独立修改

### 4. 封装数据结构差异

不同算法可以使用不同的数据结构，但对外接口统一：

| 算法 | 数据结构 | 对外接口 |
|------|----------|----------|
| RR | 双向链表 (`run_list`) | `enqueue`, `dequeue`, `pick_next` |
| Stride | 斜堆 (`lab6_run_pool`) | `enqueue`, `dequeue`, `pick_next` |
| FIFO | 双向链表 (`run_list`) | `enqueue`, `dequeue`, `pick_next` |

**好处**：调用方不需要知道底层是链表还是堆，只需要调用统一接口。

---

## 四、设计模式对比

### 传统硬编码方式（Lab 5）

```c
void schedule(void) {
    // 算法写死在这里
    do {
        le = list_next(le);
        if (next->state == PROC_RUNNABLE) break;
    } while (le != last);
}
```

**问题**：
- 要换算法必须重写整个函数
- 代码耦合度高
- 难以测试和维护

### 面向接口方式（Lab 6）

```c
void schedule(void) {
    // 只调用接口，不关心具体算法
    sched_class_enqueue(current);
    next = sched_class_pick_next();
    sched_class_dequeue(next);
}
```

**优点**：
- 切换算法只需改 1 行代码
- 添加新算法只需实现接口
- 框架代码稳定不变

---

## 五、答辩精简版

**问题：如果要添加新的调度算法，需要修改哪些代码？为什么切换变得容易？**

### 需要修改的代码（3 个文件）：

1. **新建算法实现文件**（如 `default_sched_stride.c`）
   - 实现 5 个函数：`init`, `enqueue`, `dequeue`, `pick_next`, `proc_tick`
   - 定义 `struct sched_class xxx_sched_class` 实例

2. **修改头文件**（`default_sched.h`）
   - 添加 `extern struct sched_class xxx_sched_class;`

3. **修改绑定点**（`sched.c` 的 `sched_init`）
   - 将 `sched_class = &xxx_sched_class;`

### 为什么切换容易（3 个原因）：

1. **面向接口**：`sched_class` 定义了统一的 5 个函数指针接口
2. **函数指针多态**：通过改变指针指向实现算法切换，无需修改调用代码
3. **机制策略分离**：框架代码（`schedule`、`trap`）与算法实现完全解耦

**一句话总结**：这是经典的**策略模式**在 C 语言中的实现，使得操作系统可以像插拔插件一样灵活更换调度算法。

---

## 六、实际验证

在本次实验中，我成功实现了 4 种调度算法的切换：

```c
// 在 sched.c 中，只需修改这一行即可切换：
sched_class = &default_sched_class;   // Round Robin
sched_class = &stride_sched_class;    // Stride
sched_class = &fifo_sched_class;      // FIFO
sched_class = &sjf_sched_class;       // SJF (自己实现)
```

所有切换都不需要修改 `schedule()`、`wakeup_proc()` 或 `trap.c` 中的任何代码！
