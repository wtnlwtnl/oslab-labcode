#include <defs.h>
#include <list.h>
#include <proc.h>
#include <assert.h>
#include <default_sched.h>
#include <stdio.h>

#define USE_SKEW_HEAP 1  // 定义使用斜堆实现（值为1表示启用斜堆）

/* You should define the BigStride constant here*/
/* 你应该在这里定义BigStride常量 */
/* LAB6 CHALLENGE 1: YOUR CODE */
#define BIG_STRIDE 0x7FFFFFFF /* 2310984 */  // 定义BIG_STRIDE为0x7FFFFFFF（2^31-1），用于stride计算

/* The compare function for two skew_heap_node_t's and the
 * corresponding procs*/
/* 斜堆节点的比较函数，用于比较两个进程的stride值 */
static int
proc_stride_comp_f(void *a, void *b)  // 比较函数：a和b是斜堆节点指针
{
     struct proc_struct *p = le2proc(a, lab6_run_pool);  // 通过斜堆节点获取进程p的指针
     struct proc_struct *q = le2proc(b, lab6_run_pool);  // 通过斜堆节点获取进程q的指针
     int32_t c = p->lab6_stride - q->lab6_stride;  // 计算两个进程的stride差值（使用有符号32位整数）
     if (c > 0)  // 如果差值为正数
          return 1;  // 返回1，表示p >
          return 0;  // 返回0，表 q（p的stride更大）
     else if (c == 0)  // 如果差值为0示p == q（stride相等）
     else  // 如果差值为负数
          return -1;  // 返回-1，表示p < q（p的stride更小）
}

/*
 * stride_init initializes the run-queue rq with correct assignment for
 * member variables, including:
 * stride_init 初始化运行队列rq，正确分配成员变量，包括：
 *
 *   - run_list: should be a empty list after initialization.
 *   - run_list: 初始化后应该是一个空链表
 *   - lab6_run_pool: NULL
 *   - lab6_run_pool: NULL（斜堆的根节点指针）
 *   - proc_num: 0
 *   - proc_num: 0（队列中的进程数）
 *   - max_time_slice: no need here, the variable would be assigned by the caller.
 *   - max_time_slice: 这里不需要设置，该变量由调用者分配
 *
 * hint: see libs/list.h for routines of the list structures.
 * 提示：查看libs/list.h了解链表结构的操作函数
 */
static void
stride_init(struct run_queue *rq)  // Stride调度器的初始化函数
{
     /* LAB6 CHALLENGE 1: 2310984 */
     /* (1) init the ready process list: rq->run_list
      * (1) 初始化就绪进程链表：rq->run_list
      * (2) init the run pool: rq->lab6_run_pool
      * (2) 初始化运行池（斜堆）：rq->lab6_run_pool
      * (3) set number of process: rq->proc_num to 0
      * (3) 设置进程数量：rq->proc_num 为 0
      */
     list_init(&(rq->run_list));  // 初始化run_list链表（虽然Stride主要用斜堆，但仍保留链表结构）
     rq->lab6_run_pool = NULL;  // 初始化斜堆根节点为NULL（空堆）
     rq->proc_num = 0;  // 初始化进程计数器为0
}

/*
 * stride_enqueue inserts the process ``proc'' into the run-queue
 * ``rq''. The procedure should verify/initialize the relevant members
 * of ``proc'', and then put the ``lab6_run_pool'' node into the
 * queue(since we use priority queue here). The procedure should also
 * update the meta date in ``rq'' structure.
 * stride_enqueue 将进程``proc''插入到运行队列``rq''中。
 * 该过程应该验证/初始化``proc''的相关成员，然后将``lab6_run_pool''节点
 * 放入队列（因为这里使用优先队列）。该过程还应该更新``rq''结构中的元数据。
 *
 * proc->time_slice denotes the time slices allocation for the
 * process, which should set to rq->max_time_slice.
 * proc->time_slice 表示为该进程分配的时间片，应该设置为rq->max_time_slice。
 *
 * hint: see libs/skew_heap.h for routines of the priority
 * queue structures.
 * 提示：查看libs/skew_heap.h了解优先队列结构的操作函数
 */
static void
stride_enqueue(struct run_queue *rq, struct proc_struct *proc)  // Stride调度器的入队函数
{
     /* LAB6 CHALLENGE 1: 2310984 */
     /* (1) insert the proc into rq correctly
      * (1) 正确地将proc插入到rq中
      * NOTICE: you can use skew_heap or list. Important functions
      * 注意：你可以使用斜堆或链表。重要函数：
      *         skew_heap_insert: insert a entry into skew_heap
      *         skew_heap_insert: 将一个节点插入到斜堆中
      *         list_add_before: insert  a entry into the last of list
      *         list_add_before: 将一个节点插入到链表末尾
      * (2) recalculate proc->time_slice
      * (2) 重新计算proc->time_slice
      * (3) set proc->rq pointer to rq
      * (3) 设置proc->rq指针指向rq
      * (4) increase rq->proc_num
      * (4) 增加rq->proc_num
      */
     rq->lab6_run_pool = skew_heap_insert(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_stride_comp_f);
     // 将进程的lab6_run_pool节点插入斜堆，使用proc_stride_comp_f比较函数，返回新的堆根节点
     
     if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {  // 如果时间片为0或超过最大时间片
          proc->time_slice = rq->max_time_slice;  // 重置时间片为最大时间片
     }
     proc->rq = rq;  // 设置进程的rq指针，指向它所在的运行队列
     rq->proc_num ++;  // 运行队列中的进程数量加1
}

/*
 * stride_dequeue removes the process ``proc'' from the run-queue
 * ``rq'', the operation would be finished by the skew_heap_remove
 * operations. Remember to update the ``rq'' structure.
 * stride_dequeue 从运行队列``rq''中移除进程``proc''，
 * 该操作将通过skew_heap_remove操作完成。记住要更新``rq''结构。
 *
 * hint: see libs/skew_heap.h for routines of the priority
 * queue structures.
 * 提示：查看libs/skew_heap.h了解优先队列结构的操作函数
 */
static void
stride_dequeue(struct run_queue *rq, struct proc_struct *proc)  // Stride调度器的出队函数
{
     /* LAB6 CHALLENGE 1: 2310984 */
     /* (1) remove the proc from rq correctly
      * (1) 正确地从rq中移除proc
      * NOTICE: you can use skew_heap or list. Important functions
      * 注意：你可以使用斜堆或链表。重要函数：
      *         skew_heap_remove: remove a entry from skew_heap
      *         skew_heap_remove: 从斜堆中移除一个节点
      *         list_del_init: remove a entry from the  list
      *         list_del_init: 从链表中移除一个节点
      */
     rq->lab6_run_pool = skew_heap_remove(rq->lab6_run_pool, &(proc->lab6_run_pool), proc_stride_comp_f);
     // 从斜堆中移除进程的lab6_run_pool节点，使用proc_stride_comp_f比较函数，返回新的堆根节点
     
     rq->proc_num --;  // 运行队列中的进程数量减1
}

/*
 * stride_pick_next pick the element from the ``run-queue'', with the
 * minimum value of stride, and returns the corresponding process
 * pointer. The process pointer would be calculated by macro le2proc,
 * see kern/process/proc.h for definition. Return NULL if
 * there is no process in the queue.
 * stride_pick_next 从``运行队列''中选择stride值最小的元素，
 * 并返回对应的进程指针。进程指针通过宏le2proc计算得到，
 * 定义见kern/process/proc.h。如果队列中没有进程则返回NULL。
 *
 * When one proc structure is selected, remember to update the stride
 * property of the proc. (stride += BIG_STRIDE / priority)
 * 当一个进程结构被选中时，记住要更新该进程的stride属性。
 * (stride += BIG_STRIDE / priority)
 *
 * hint: see libs/skew_heap.h for routines of the priority
 * queue structures.
 * 提示：查看libs/skew_heap.h了解优先队列结构的操作函数
 */
static struct proc_struct *
stride_pick_next(struct run_queue *rq)  // Stride调度器的选择下一个进程函数
{
     /* LAB6 CHALLENGE 1: 2310984 */
     /* (1) get a  proc_struct pointer p  with the minimum value of stride
      * (1) 获取一个stride值最小的proc_struct指针p
             (1.1) If using skew_heap, we can use le2proc get the p from rq->lab6_run_pol
             (1.1) 如果使用斜堆，我们可以使用le2proc从rq->lab6_run_pool获取p
             (1.2) If using list, we have to search list to find the p with minimum stride value
             (1.2) 如果使用链表，我们必须搜索链表找到stride值最小的p
      * (2) update p;s stride value: p->lab6_stride
      * (2) 更新p的stride值：p->lab6_stride
      * (3) return p
      * (3) 返回p
      */
     if (rq->lab6_run_pool == NULL) return NULL;  // 如果斜堆为空（根节点为NULL），返回NULL
     struct proc_struct *p = le2proc(rq->lab6_run_pool, lab6_run_pool);  // 从斜堆根节点获取stride最小的进程指针
     if (p->lab6_priority == 0) {  // 如果进程优先级为0（特殊情况，避免除0）
          p->lab6_stride += BIG_STRIDE;  // stride增加BIG_STRIDE（相当于优先级为1）
     } else {  // 如果优先级不为0（正常情况）
          p->lab6_stride += BIG_STRIDE / p->lab6_priority;  // stride增加 BIG_STRIDE/priority（步长）
     }
     return p;  // 返回选中的进程指针
}

/*
 * stride_proc_tick works with the tick event of current process. You
 * should check whether the time slices for current process is
 * exhausted and update the proc struct ``proc''. proc->time_slice
 * denotes the time slices left for current
 * process. proc->need_resched is the flag variable for process
 * switching.
 * stride_proc_tick 处理当前进程的时钟中断事件。你应该检查当前进程的
 * 时间片是否已耗尽，并更新进程结构``proc''。proc->time_slice表示
 * 当前进程剩余的时间片。proc->need_resched是进程切换的标志变量。
 */
static void
stride_proc_tick(struct run_queue *rq, struct proc_struct *proc)  // Stride调度器的时钟中断处理函数
{
     /* LAB6 CHALLENGE 1: 2310984 */
     if (proc->time_slice > 0) {  // 如果当前进程的时间片大于0
          proc->time_slice --;  // 时间片减1
     }
     if (proc->time_slice == 0) {  // 如果时间片已经用完（减到0）
          proc->need_resched = 1;  // 设置需要重新调度标志为1，触发进程切换
     }
}

struct sched_class stride_sched_class = {  // 定义Stride调度类结构体
    .name = "stride_scheduler",  // 调度器名称为"stride_scheduler"
    .init = stride_init,  // 初始化函数指针指向stride_init
    .enqueue = stride_enqueue,  // 入队函数指针指向stride_enqueue
    .dequeue = stride_dequeue,  // 出队函数指针指向stride_dequeue
    .pick_next = stride_pick_next,  // 选择下一个进程函数指针指向stride_pick_next
    .proc_tick = stride_proc_tick,  // 时钟中断处理函数指针指向stride_proc_tick
};