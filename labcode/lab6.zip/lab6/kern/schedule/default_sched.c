#include <defs.h>  // 包含基本定义
#include <list.h>  // 包含链表操作函数
#include <proc.h>  // 包含进程控制块定义
#include <assert.h>  // 包含断言宏
#include <default_sched.h>  // 包含调度器接口定义

/*
 * RR_init initializes the run-queue rq with correct assignment for
 * member variables, including:
 * RR_init函数初始化运行队列rq，正确分配成员变量，包括：
 *
 *   - run_list: should be an empty list after initialization.
 *   - run_list: 初始化后应该是一个空链表
 *   - proc_num: set to 0
 *   - proc_num: 设置为0
 *   - max_time_slice: no need here, the variable would be assigned by the caller.
 *   - max_time_slice: 这里不需要设置，该变量将由调用者分配
 *
 * hint: see libs/list.h for routines of the list structures.
 * 提示: 查看libs/list.h了解链表结构的操作函数
 */
static void  // 静态函数，仅在本文件内可见
RR_init(struct run_queue *rq)  // RR调度算法的初始化函数，参数为运行队列指针
{
    // LAB6: 2310984
    list_init(&(rq->run_list));  // 初始化运行队列的链表头，将前后指针指向自己形成空链表
    rq->proc_num = 0;  // 将队列中的进程数量设置为0
}

/*
 * RR_enqueue inserts the process ``proc'' into the tail of run-queue
 * ``rq''. The procedure should verify/initialize the relevant members
 * of ``proc'', and then put the ``run_link'' node into the queue.
 * The procedure should also update the meta data in ``rq'' structure.
 * RR_enqueue将进程``proc''插入到运行队列``rq''的尾部。
 * 该过程应该验证/初始化``proc''的相关成员，然后将``run_link''节点放入队列。
 * 该过程还应该更新``rq''结构中的元数据。
 *
 * proc->time_slice denotes the time slices allocation for the
 * process, which should set to rq->max_time_slice.
 * proc->time_slice表示为该进程分配的时间片，应该设置为rq->max_time_slice。
 *
 * hint: see libs/list.h for routines of the list structures.
 * 提示: 查看libs/list.h了解链表结构的操作函数
 */
static void  // 静态函数
RR_enqueue(struct run_queue *rq, struct proc_struct *proc)  // RR调度算法的入队函数，参数为运行队列和要加入的进程
{
    // LAB6: 2310984
    assert(list_empty(&(proc->run_link)));  // 断言：进程的run_link节点应该是空的（不在任何队列中）
    list_add_before(&(rq->run_list), &(proc->run_link));  // 将进程的run_link节点添加到队列链表头之前（即队列尾部，实现FIFO）
    if (proc->time_slice == 0 || proc->time_slice > rq->max_time_slice) {  // 如果进程的时间片为0或超过最大时间片
        proc->time_slice = rq->max_time_slice;  // 重置进程的时间片为队列的最大时间片
    }
    proc->rq = rq;  // 设置进程的rq指针，指向它所在的运行队列
    rq->proc_num ++;  // 运行队列中的进程数量加1
}

/*
 * RR_dequeue removes the process ``proc'' from the front of run-queue
 * ``rq'', the operation would be finished by the list_del_init operation.
 * Remember to update the ``rq'' structure.
 * RR_dequeue从运行队列``rq''的前端移除进程``proc''，
 * 该操作将通过list_del_init操作完成。
 * 记住要更新``rq''结构。
 *
 * hint: see libs/list.h for routines of the list structures.
 * 提示: 查看libs/list.h了解链表结构的操作函数
 */
static void  // 静态函数
RR_dequeue(struct run_queue *rq, struct proc_struct *proc)  // RR调度算法的出队函数，参数为运行队列和要移除的进程
{
    // LAB6: 2310984
    assert(!list_empty(&(proc->run_link)) && proc->rq == rq);  // 断言：进程的run_link不为空且进程确实在这个队列中
    list_del_init(&(proc->run_link));  // 从链表中删除进程的run_link节点，并重新初始化该节点（前后指针指向自己）
    rq->proc_num --;  // 运行队列中的进程数量减1
}

/*
 * RR_pick_next picks the element from the front of ``run-queue'',
 * and returns the corresponding process pointer. The process pointer
 * would be calculated by macro le2proc, see kern/process/proc.h
 * for definition. Return NULL if there is no process in the queue.
 * RR_pick_next从``运行队列''的前端选取元素，
 * 并返回对应的进程指针。进程指针将通过宏le2proc计算得到，
 * 定义见kern/process/proc.h。如果队列中没有进程则返回NULL。
 *
 * hint: see libs/list.h for routines of the list structures.
 * 提示: 查看libs/list.h了解链表结构的操作函数
 */
static struct proc_struct *  // 静态函数，返回进程指针
RR_pick_next(struct run_queue *rq)  // RR调度算法的选择下一个进程函数，参数为运行队列
{
    // LAB6: 2310984
    list_entry_t *le = list_next(&(rq->run_list));  // 获取队列链表头的下一个节点（即队首进程的run_link）
    if (le != &(rq->run_list)) {  // 如果该节点不是链表头本身（说明队列非空）
        return le2proc(le, run_link);  // 通过le2proc宏将链表节点转换为进程指针并返回
    }
    return NULL;  // 如果队列为空，返回NULL
}

/*
 * RR_proc_tick works with the tick event of current process. You
 * should check whether the time slices for current process is
 * exhausted and update the proc struct ``proc''. proc->time_slice
 * denotes the time slices left for current process. proc->need_resched
 * is the flag variable for process switching.
 * RR_proc_tick处理当前进程的时钟中断事件。你应该检查当前进程的时间片
 * 是否已耗尽，并更新进程结构``proc''。proc->time_slice表示当前进程
 * 剩余的时间片。proc->need_resched是进程切换的标志变量。
 */
static void  // 静态函数
RR_proc_tick(struct run_queue *rq, struct proc_struct *proc)  // RR调度算法的时钟中断处理函数，参数为运行队列和当前进程
{
    // LAB6: 2310984
    if (proc->time_slice > 0) {  // 如果当前进程的时间片大于0
        proc->time_slice --;  // 时间片减1
    }
    if (proc->time_slice == 0) {  // 如果时间片已经用完（减到0）
        proc->need_resched = 1;  // 设置需要重新调度标志为1，触发进程切换
    }
}

struct sched_class default_sched_class = {  // 定义默认调度类结构体（RR调度器）
    .name = "RR_scheduler",  // 调度器名称为"RR_scheduler"
    .init = RR_init,  // 初始化函数指针指向RR_init
    .enqueue = RR_enqueue,  // 入队函数指针指向RR_enqueue
    .dequeue = RR_dequeue,  // 出队函数指针指向RR_dequeue
    .pick_next = RR_pick_next,  // 选择下一个进程函数指针指向RR_pick_next
    .proc_tick = RR_proc_tick,  // 时钟中断处理函数指针指向RR_proc_tick
};