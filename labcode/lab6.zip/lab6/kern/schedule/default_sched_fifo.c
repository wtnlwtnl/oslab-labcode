#include <defs.h>  // 包含基本定义
#include <list.h>  // 包含链表操作函数
#include <proc.h>  // 包含进程控制块定义
#include <assert.h>  // 包含断言宏
#include <default_sched.h>  // 包含调度器接口定义

// FIFO调度器初始化函数
static void
FIFO_init(struct run_queue *rq)  // 参数rq：指向运行队列的指针
{
    list_init(&(rq->run_list));  // 初始化运行队列的链表头，将前后指针都指向自己，形成空链表
    rq->proc_num = 0;  // 将队列中的进程数量初始化为0
}

// FIFO调度器入队函数
static void
FIFO_enqueue(struct run_queue *rq, struct proc_struct *proc)  // 参数：运行队列rq和要入队的进程proc
{
    assert(list_empty(&(proc->run_link)));  // 断言：检查进程的run_link节点为空（确保进程不在任何队列中）
    list_add_before(&(rq->run_list), &(proc->run_link));  // 将进程的run_link节点添加到队列链表头之前（即队尾），实现FIFO
    proc->rq = rq;  // 设置进程的rq指针，指向它所在的运行队列
    rq->proc_num ++;  // 运行队列中的进程数量加1
}

// FIFO调度器出队函数
static void
FIFO_dequeue(struct run_queue *rq, struct proc_struct *proc)  // 参数：运行队列rq和要出队的进程proc
{
    assert(!list_empty(&(proc->run_link)) && proc->rq == rq);  // 断言：检查进程的run_link不为空且进程确实在这个队列中
    list_del_init(&(proc->run_link));  // 从链表中删除进程的run_link节点，并重新初始化该节点（前后指针指向自己）
    rq->proc_num --;  // 运行队列中的进程数量减1
}

// FIFO调度器选择下一个进程函数
static struct proc_struct *
FIFO_pick_next(struct run_queue *rq)  // 参数：运行队列rq，返回值：下一个要运行的进程指针
{
    list_entry_t *le = list_next(&(rq->run_list));  // 获取队列链表头的下一个节点（即队首进程的run_link）
    if (le != &(rq->run_list)) {  // 如果该节点不是链表头本身（说明队列非空）
        return le2proc(le, run_link);  // 通过le2proc宏将链表节点转换为进程指针并返回（队首进程）
    }
    return NULL;  // 如果队列为空，返回NULL
}

// FIFO调度器时钟中断处理函数
static void
FIFO_proc_tick(struct run_queue *rq, struct proc_struct *proc)  // 参数：运行队列rq和当前进程proc
{
    // FIFO is non-preemptive
    // FIFO是非抢占式调度，所以时钟中断处理函数为空
    // 不需要递减时间片，不需要设置need_resched标志
    // 进程会一直运行直到主动退出、阻塞或完成
}

struct sched_class fifo_sched_class = {  // 定义FIFO调度类结构体
    .name = "FIFO_scheduler",  // 调度器名称为"FIFO_scheduler"
    .init = FIFO_init,  // 初始化函数指针指向FIFO_init
    .enqueue = FIFO_enqueue,  // 入队函数指针指向FIFO_enqueue
    .dequeue = FIFO_dequeue,  // 出队函数指针指向FIFO_dequeue
    .pick_next = FIFO_pick_next,  // 选择下一个进程函数指针指向FIFO_pick_next
    .proc_tick = FIFO_proc_tick,  // 时钟中断处理函数指针指向FIFO_proc_tick（空函数）
};