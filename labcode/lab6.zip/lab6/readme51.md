# 进程调度流程详解（通俗易懂版）

## 问题

详细解释"时钟中断触发、proc_tick 被调用、schedule() 函数执行、调度类各个函数的调用顺序"这个过程，每一步的作用、流程以及步骤之间的连接方式。

---

## 一、场景设定

假设现在有 3 个进程：
- **进程 A**（正在运行，时间片还剩 1）
- **进程 B**（在就绪队列中等待）
- **进程 C**（在就绪队列中等待）

---

## 二、完整流程的 6 个步骤

### 第 1 步：时钟中断触发（硬件层面）

```
进程 A 正在愉快地运行...
        │
        │  ← 硬件定时器产生一个时钟中断（每 10ms 一次）
        ▼
CPU 被迫暂停进程 A，跳转到内核的 trap() 函数
```

**作用**：这是硬件强制打断当前进程的机制。就像闹钟响了，不管你在干什么都要先处理闹钟。

**连接方式**：硬件中断 → CPU 自动跳转到预设的中断处理入口（`trap()`）

---

### 第 2 步：`trap()` → `trap_dispatch()` → `interrupt_handler()`

```c
// kern/trap/trap.c
void trap(struct trapframe *tf) {
    // 保存进程 A 的现场（寄存器等）
    trap_dispatch(tf);  // 分发处理
    // ... 后面还有检查 need_resched 的逻辑
}
```

`trap_dispatch()` 会根据中断类型调用不同的处理函数。时钟中断对应的是 `IRQ_S_TIMER`：

```c
case IRQ_S_TIMER:
    clock_set_next_event();           // 设置下一次时钟中断
    ticks++;                          // 全局计数器 +1
    sched_class_proc_tick(current);   // ★ 关键：调用调度类的时钟处理
    break;
```

**作用**：识别这是时钟中断，然后调用调度相关的处理函数。

**连接方式**：`trap()` 调用 `trap_dispatch()`，`trap_dispatch()` 调用 `interrupt_handler()`，`interrupt_handler()` 里 `switch-case` 匹配到时钟中断。

---

### 第 3 步：`sched_class_proc_tick()` → `proc_tick()`

```c
// kern/schedule/sched.c
void sched_class_proc_tick(struct proc_struct *proc) {
    if (proc != idleproc) {
        sched_class->proc_tick(rq, proc);  // 调用具体算法的 proc_tick
    } else {
        proc->need_resched = 1;  // idle 进程直接标记要调度
    }
}
```

对于 RR 算法，`proc_tick` 的实现是：

```c
// kern/schedule/default_sched.c
static void RR_proc_tick(struct run_queue *rq, struct proc_struct *proc) {
    if (proc->time_slice > 0) {
        proc->time_slice--;  // 时间片减 1
    }
    if (proc->time_slice == 0) {
        proc->need_resched = 1;  // ★ 关键：标记"需要调度"
    }
}
```

**在我们的场景中**：
- 进程 A 的 `time_slice` 从 1 减到 0
- 然后设置 `proc_A->need_resched = 1`

**作用**：检查当前进程是否用完了时间片。如果用完了，就**标记**它应该让出 CPU。

**为什么只是"标记"而不是直接调度？** 因为现在还在中断处理程序里面，不能直接切换进程（会破坏中断处理的完整性）。

**连接方式**：`interrupt_handler()` 调用 `sched_class_proc_tick()`，后者通过函数指针调用 `RR_proc_tick()`。

---

### 第 4 步：中断处理完成，返回前检查 `need_resched`

中断处理完成后，回到 `trap()` 函数的后半部分：

```c
// kern/trap/trap.c
void trap(struct trapframe *tf) {
    // ... 前面是中断处理 ...
    
    if (!in_kernel) {  // 如果原来是用户态
        if (current->need_resched) {  // ★ 检查标志
            schedule();  // 调用调度函数
        }
    }
}
```

**在我们的场景中**：
- 进程 A 的 `need_resched == 1`
- 检查通过，调用 `schedule()`

**作用**：这是一个**安全的调度点**。中断处理已经完成，现在可以安全地进行进程切换了。

**连接方式**：`trap_dispatch()` 返回后，`trap()` 继续执行后续代码，检查标志并调用 `schedule()`。

---

### 第 5 步：`schedule()` 函数执行

```c
// kern/schedule/sched.c
void schedule(void) {
    local_intr_save(intr_flag);  // 关中断
    {
        current->need_resched = 0;  // 清除标志
        
        // 步骤 1：把当前进程放回队列
        if (current->state == PROC_RUNNABLE) {
            sched_class_enqueue(current);  // 进程 A 入队
        }
        
        // 步骤 2：选择下一个进程
        next = sched_class_pick_next();  // 选中进程 B
        
        // 步骤 3：把选中的进程从队列移除
        sched_class_dequeue(next);  // 进程 B 出队
        
        // 步骤 4：执行切换
        if (next != current) {
            proc_run(next);  // 切换到进程 B
        }
    }
    local_intr_restore(intr_flag);  // 恢复中断
}
```

**在我们的场景中**：

| 操作 | 调度类函数 | 队列变化 |
|------|-----------|----------|
| 进程 A 放回队列 | `enqueue(A)` | 队列: [B, C] → [B, C, A] |
| 选择下一个 | `pick_next()` | 返回 B |
| 进程 B 移出队列 | `dequeue(B)` | 队列: [B, C, A] → [C, A] |

**作用**：这是调度的核心逻辑：
1. 把当前进程放回去排队
2. 从队列里选一个新的
3. 切换过去

**连接方式**：`schedule()` 通过 `sched_class` 的函数指针调用具体算法的 `enqueue`、`pick_next`、`dequeue`。

---

### 第 6 步：`proc_run()` 上下文切换

```c
void proc_run(struct proc_struct *proc) {
    struct proc_struct *prev = current;
    current = proc;  // current 指向进程 B
    
    // 切换页表
    lcr3(proc->cr3);
    
    // 切换寄存器上下文
    switch_to(&(prev->context), &(proc->context));
}
```

**作用**：真正的"换人"操作：
- 切换页表（换内存空间）
- 切换寄存器（换执行状态）

**结果**：`switch_to` 之后，CPU 开始执行进程 B 的代码！

---

## 三、完整流程图（简化版）

```
┌─────────────────────────────────────────────────────────────┐
│ 进程 A 运行中 (time_slice = 1)                               │
└─────────────────────────────────────────────────────────────┘
                    │
                    │ ← 时钟中断！
                    ▼
┌─────────────────────────────────────────────────────────────┐
│ trap() → interrupt_handler()                                │
│         │                                                   │
│         └→ sched_class_proc_tick()                         │
│               │                                             │
│               └→ time_slice-- (变成0)                       │
│               └→ need_resched = 1  ← 标记"要换人"           │
└─────────────────────────────────────────────────────────────┘
                    │
                    │ ← 中断处理完毕
                    ▼
┌─────────────────────────────────────────────────────────────┐
│ trap() 返回前检查                                            │
│         │                                                   │
│         └→ if (need_resched) → schedule()                  │
└─────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────┐
│ schedule()                                                  │
│         │                                                   │
│         ├→ enqueue(A)      把 A 放回队列                    │
│         ├→ pick_next()     选出 B                          │
│         ├→ dequeue(B)      把 B 从队列移除                  │
│         └→ proc_run(B)     切换到 B                        │
└─────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────┐
│ 进程 B 开始运行！                                            │
└─────────────────────────────────────────────────────────────┘
```

---

## 四、调度类 5 个函数的调用顺序和时机

### 函数列表

| 函数 | 调用时机 | 调用者 |
|------|----------|--------|
| `init` | 系统启动时 | `sched_init()` |
| `proc_tick` | 每次时钟中断 | `sched_class_proc_tick()` |
| `enqueue` | 进程入队 | `sched_class_enqueue()` |
| `pick_next` | 选择下一个进程 | `sched_class_pick_next()` |
| `dequeue` | 进程出队 | `sched_class_dequeue()` |

### 完整的调用顺序

```
系统启动
    │
    ▼
┌─────────────────────────────────────────┐
│ ① init(rq)                              │  ← 只调用一次，初始化运行队列
└─────────────────────────────────────────┘
    │
    │ (系统开始运行，进程被创建...)
    │
    ▼
┌─────────────────────────────────────────┐
│ ② enqueue(rq, proc)                     │  ← 进程创建/唤醒时入队
│    （wakeup_proc 调用）                  │
└─────────────────────────────────────────┘
    │
    │ (每隔 10ms 时钟中断...)
    │
    ▼
┌─────────────────────────────────────────┐
│ ③ proc_tick(rq, proc)                   │  ← 每次时钟中断都调用
│    - 扣减 time_slice                     │
│    - 若为 0，设置 need_resched = 1       │
└─────────────────────────────────────────┘
    │
    │ (need_resched == 1，触发调度)
    │
    ▼
┌─────────────────────────────────────────┐
│ schedule() 被调用，依次执行：             │
│                                         │
│ ④ enqueue(rq, current)                  │  ← 当前进程放回队列
│         │                               │
│         ▼                               │
│ ⑤ pick_next(rq) → 返回 next            │  ← 选择下一个进程
│         │                               │
│         ▼                               │
│ ⑥ dequeue(rq, next)                     │  ← 选中的进程离开队列
│         │                               │
│         ▼                               │
│    proc_run(next)                       │  ← 上下文切换
└─────────────────────────────────────────┘
    │
    │ (新进程运行，循环回到 ③)
    ▼
```

### 一句话总结

**初始化时调用 `init`，每次时钟中断调用 `proc_tick`，触发调度时按 `enqueue` → `pick_next` → `dequeue` 顺序调用。**

---

## 五、核心问题解答

### Q1: 为什么要分成"标记"和"实际调度"两步？

因为**中断处理程序里不能做复杂的事情**。`proc_tick` 是在中断上下文中调用的，如果直接在这里切换进程：
- 中断还没处理完就跑去执行别的进程了
- 可能导致中断丢失、栈混乱等严重问题

所以用 `need_resched` 先"记个小本本"，等中断处理完了、到了安全的地方再真正切换。

### Q2: `enqueue` → `pick_next` → `dequeue` 为什么是这个顺序？

1. **先 `enqueue(current)`**：把当前进程放回去，让它有资格被选中（公平竞争）
2. **再 `pick_next()`**：从所有候选者中选出最合适的
3. **最后 `dequeue(next)`**：选中的进程要离开队列去运行

这样保证了当前进程也有可能被再次选中（如果它优先级最高的话）。

### Q3: 每一步之间是怎么连接的？

| 从 | 到 | 连接方式 |
|----|----|----|
| 硬件中断 | `trap()` | CPU 自动跳转（硬件机制） |
| `trap()` | `interrupt_handler()` | 函数调用 |
| `interrupt_handler()` | `proc_tick()` | 通过 `sched_class` 函数指针调用 |
| `proc_tick()` | `schedule()` | 设置 `need_resched` 标志，`trap()` 返回前检查并调用 |
| `schedule()` | `enqueue/pick_next/dequeue` | 通过 `sched_class` 函数指针调用 |
| `schedule()` | `proc_run()` | 函数调用 |
