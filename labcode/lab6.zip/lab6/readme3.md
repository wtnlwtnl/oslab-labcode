# 调度器框架函数分析

## 问题

分析 `sched_init()`、`wakeup_proc()` 和 `schedule()` 函数在 Lab 6 中的实现变化，理解这些函数如何与具体的调度算法解耦。

---

## 详细分析

通过对比 Lab 5 的 `kern/schedule/sched.c` 和 Lab 6 的 `kern/schedule/sched.c`，我们可以清晰地看到调度器框架是如何从"硬编码"演变为"面向接口编程"的。

### 1. `sched_init` 函数：框架的引入

**Lab 5**: **不存在**此函数。

*   在 Lab 5 的 `kern/init/init.c` 中，初始化流程是 `pmm_init` -> `pic_init` -> ... -> `proc_init` -> `clock_init` -> `cpu_idle`。没有专门的调度器初始化步骤。

**Lab 6**:

```c
void sched_init(void) {
    list_init(&timer_list);
    sched_class = &default_sched_class; // 绑定具体的调度策略（如RR）
    rq = &__rq;
    rq->max_time_slice = MAX_TIME_SLICE;
    sched_class->init(rq); // 初始化具体的调度算法
    // ...
}
```

*   **分析**: Lab 6 引入了 `sched_init`，它的核心作用是**绑定接口实现**。它将全局的 `sched_class` 指针指向了具体的算法（如 `default_sched_class`），从而确定了系统将使用哪种调度策略。

### 2. `wakeup_proc` 函数：入队逻辑的解耦

**Lab 5**:

```c
void wakeup_proc(struct proc_struct *proc) {
    // ...
    if (proc->state != PROC_RUNNABLE) {
        proc->state = PROC_RUNNABLE; // 仅仅修改状态
        proc->wait_state = 0;
    }
    // ...
}
```

*   **Lab 5 逻辑**: 仅仅将进程状态改为 `PROC_RUNNABLE`。因为 Lab 5 的调度器是遍历整个进程链表，所以不需要显式地将进程加入"就绪队列"。

**Lab 6**:

```c
void wakeup_proc(struct proc_struct *proc) {
    // ...
    if (proc->state != PROC_RUNNABLE) {
        proc->state = PROC_RUNNABLE;
        proc->wait_state = 0;
        if (proc != current) {
            sched_class_enqueue(proc); // 【关键差异】调用接口入队
        }
    }
    // ...
}
```

*   **Lab 6 逻辑**: 除了修改状态，还调用了 `sched_class_enqueue(proc)`。这行代码最终会调用 `sched_class->enqueue(rq, proc)`。
*   **解耦点**: `wakeup_proc` 不再关心进程是放入链表头部、尾部，还是放入优先队列（斜堆）。它只负责通知调度器"有一个进程准备好了"，具体怎么放，由 `sched_class` 决定。

### 3. `schedule` 函数：调度策略的解耦

这是变化最大的地方。

**Lab 5 (硬编码的 FIFO/RR 混合)**:

```c
void schedule(void) {
    // ...
    // 直接遍历 proc_list 链表
    last = (current == idleproc) ? &proc_list : &(current->list_link);
    le = last;
    do {
        if ((le = list_next(le)) != &proc_list) {
            next = le2proc(le, list_link);
            if (next->state == PROC_RUNNABLE) { // 只要是 RUNNABLE 就选中
                break;
            }
        }
    } while (le != last);
    // ...
    proc_run(next);
}
```

*   **Lab 5 逻辑**: 调度算法被**写死**在 `schedule` 函数里。它只能按顺序遍历链表，找到第一个就绪的进程。如果要改用优先级调度，必须重写整个 `schedule` 函数。

**Lab 6 (面向接口)**:

```c
void schedule(void) {
    // ...
    current->need_resched = 0;
    if (current->state == PROC_RUNNABLE) {
        sched_class_enqueue(current); // 当前进程放回队列
    }
    
    if ((next = sched_class_pick_next()) != NULL) { // 【关键差异】调用接口选择下一个
        sched_class_dequeue(next); // 从队列中取出
    }
    
    if (next == NULL) {
        next = idleproc;
    }
    // ...
    proc_run(next);
}
```

*   **Lab 6 逻辑**: `schedule` 函数完全不知道具体的调度算法。它只做三件事：
    1.  把当前进程放回队列 (`enqueue`)。
    2.  问调度器要下一个进程 (`pick_next`)。
    3.  执行切换 (`proc_run`)。
*   **解耦点**: `pick_next` 内部可以是简单的链表头取出（FIFO），也可以是复杂的斜堆最小值取出（Stride）。`schedule` 函数本身不需要任何修改就能支持新的算法。

### 4. 三个函数的对比总结表

| 函数 | Lab 5 | Lab 6 | 解耦方式 |
|------|-------|-------|----------|
| `sched_init` | 不存在 | 新增，绑定 `sched_class` 指针 | 通过指针赋值选择算法 |
| `wakeup_proc` | 仅修改状态 | 修改状态 + 调用 `enqueue` | 入队操作委托给 `sched_class` |
| `schedule` | 硬编码遍历链表 | 调用 `pick_next` 接口 | 选择逻辑委托给 `sched_class` |

### 5. 设计模式总结

Lab 6 通过这三个函数的改造，实现了**机制与策略的分离**：

1.  **机制 (Mechanism)**: `schedule` 和 `wakeup_proc` 负责通用的流程控制（如关中断、修改状态、触发上下文切换）。
2.  **策略 (Policy)**: `sched_class` 的具体实现（如 `default_sched.c`）负责决定谁先运行（通过 `enqueue` 和 `pick_next` 维护队列顺序）。

这种设计使得你在做 Lab 6 时，只需要编写 `default_sched_stride.c` 或 `default_sched_sjf.c`，而不需要去动内核核心的 `schedule` 函数，极大地提高了内核的可扩展性。

---

## 答辩精简版

**核心观点：**
Lab 5 到 Lab 6 的最大变化在于从**"硬编码的简单轮询"**演变为**"面向接口的调度框架"**，实现了**机制（Mechanism）与策略（Policy）的分离**。

具体体现在以下三个关键函数的改造上：

### 1. 初始化阶段：`sched_init` 的引入

*   **Lab 5（无此函数）**：调度初始化是隐式的，没有专门的入口。系统启动后直接进入 `cpu_idle`，依赖后续的硬编码逻辑运行。
*   **Lab 6（新增）**：引入了 `sched_init` 函数。
    *   **作用**：这是调度框架的**绑定点**。它将全局的 `sched_class` 指针指向了具体的算法实现（如 `default_sched_class` 或 `stride_sched_class`）。
    *   **意义**：这使得我们在不修改内核核心代码的情况下，仅通过修改指针指向就能切换整个系统的调度算法。

### 2. 进程唤醒：`wakeup_proc` 的职责延伸

*   **Lab 5**：
    *   **逻辑**：仅仅将进程状态修改为 `PROC_RUNNABLE`。
    *   **局限**：因为它假设调度器会遍历所有进程链表，所以不需要显式的"入队"操作。
*   **Lab 6**：
    *   **逻辑**：在修改状态为 `PROC_RUNNABLE` 后，**显式调用了 `sched_class_enqueue`**。
    *   **意义**：将"进程变更为就绪态"和"放入就绪队列"这两个动作解耦。`wakeup_proc` 不再关心进程是插到队头、队尾还是优先队列的某个位置，这完全由具体的调度类（`sched_class`）决定。

### 3. 核心调度：`schedule` 的完全解耦（重点）

*   **Lab 5（硬编码）**：
    *   **代码特征**：函数内部包含了一个 `do...while` 循环，直接遍历全局的 `proc_list` 链表来寻找下一个 `RUNNABLE` 的进程。
    *   **问题**：调度算法（简单的轮询）被写死在 `schedule` 函数里。如果要实现优先级调度，必须重写这个核心函数，扩展性极差。
*   **Lab 6（面向接口）**：
    *   **代码特征**：循环遍历被移除，取而代之的是三个标准接口调用：
        1.  `sched_class_enqueue(current)`：如果当前进程还活着，放回队列。
        2.  `sched_class_pick_next()`：问调度器要下一个进程。
        3.  `sched_class_dequeue(next)`：从队列中取出该进程。
    *   **意义**：`schedule` 函数变成了纯粹的**机制**执行者（负责上下文切换），而**策略**（谁是下一个）完全委托给了 `sched_class`。

### 总结（一句话点题）

Lab 6 通过定义 `sched_class` 接口，将调度算法的具体实现（如 FIFO、RR、Stride）从内核核心的 `schedule` 函数中剥离出来，使得内核可以像插拔插件一样灵活地更换调度策略，这正是现代操作系统设计的核心思想。

---

## 助教可能会追问的问题预案

**问：Lab 5 为什么不需要 `enqueue`？**

*   **答**：因为 Lab 5 的调度器是每次调度时遍历整个 `proc_list`（所有进程的链表），只要状态是 `RUNNABLE` 就执行，所以不需要一个专门的"就绪队列"来维护顺序。

**问：Lab 6 的 `pick_next` 在 Stride 算法里做了什么？**

*   **答**：在 Stride 算法中，`pick_next` 不再是简单的取链表头，而是从**斜堆（Skew Heap）**中取出 `stride` 值最小的那个进程，这体现了接口封装的好处——上层不需要知道底层是链表还是堆。

**问：这种设计有什么实际好处？**

*   **答**：在本次实验中，我正是利用这一机制，通过修改 `sched.c` 中的 `sched_class` 指针指向，成功实现了从默认的 Round Robin 到 Stride、FIFO 和 SJF 调度器的无缝切换，而不需要修改任何 `schedule` 或 `trap` 中的代码。
