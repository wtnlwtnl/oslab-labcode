#include <list.h>  // 包含双向链表操作函数
#include <sync.h>  // 包含同步原语（关中断/开中断等）
#include <proc.h>  // 包含进程控制块定义
#include <sched.h>  // 包含调度器接口定义
#include <stdio.h>  // 包含标准输入输出函数
#include <assert.h>  // 包含断言宏定义
#include <default_sched.h>  // 包含默认调度算法的实现

// 定时器链表
static list_entry_t timer_list;  // 定时器链表头，用于管理系统定时器

static struct sched_class *sched_class;  // 调度类指针，指向当前使用的调度算法

static struct run_queue *rq;  // 运行队列指针，指向全局就绪队列

// 这几个函数是对调度类接口的二次封装,添加了一些通用逻辑

static inline void  // 内联函数，减少函数调用开销
sched_class_enqueue(struct proc_struct *proc)  // 进程入队封装函数
{
    if (proc != idleproc)  // 如果不是idle空闲进程
    {
        sched_class->enqueue(rq, proc);  // 调用具体调度算法的入队函数
    }
}

static inline void  // 内联函数
sched_class_dequeue(struct proc_struct *proc)  // 进程出队封装函数
{
    sched_class->dequeue(rq, proc);  // 调用具体调度算法的出队函数
}

static inline struct proc_struct *  // 内联函数，返回下一个进程
sched_class_pick_next(void)  // 选择下一个进程的封装函数
{
    return sched_class->pick_next(rq);  // 调用具体调度算法的选择函数
}

void sched_class_proc_tick(struct proc_struct *proc)  // 时钟中断处理封装函数
{
    if (proc != idleproc)  // 如果当前进程不是idle进程
    {
        sched_class->proc_tick(rq, proc);  // 调用调度算法的时钟中断处理函数
    }
    else  // 如果是idle进程
    {
        proc->need_resched = 1;  // 直接标记需要重新调度
    }
}

static struct run_queue __rq;  // 定义全局唯一的运行队列实例

void sched_init(void)  // 调度器初始化函数
{
    list_init(&timer_list);  // 初始化定时器链表

    sched_class = &stride_sched_class;  // 绑定默认调度算法（RR或Stride）

    rq = &__rq;  // 让运行队列指针指向全局队列实例
    rq->max_time_slice = MAX_TIME_SLICE;  // 设置最大时间片为5
    sched_class->init(rq);  // 调用调度算法的初始化函数

    cprintf("sched class: %s\n", sched_class->name);  // 打印当前使用的调度算法名称
}

void wakeup_proc(struct proc_struct *proc)  // 唤醒进程函数
{
    assert(proc->state != PROC_ZOMBIE);  // 断言：进程不能是僵尸状态
    bool intr_flag;  // 定义中断状态标志变量
    local_intr_save(intr_flag);  // 关中断并保存中断状态，进入临界区
    {
        if (proc->state != PROC_RUNNABLE)  // 如果进程当前不是就绪状态
        {
            proc->state = PROC_RUNNABLE;  // 将进程状态设置为就绪
            proc->wait_state = 0;  // 清除等待状态标志
            if (proc != current)  // 如果不是当前正在运行的进程
            {
                sched_class_enqueue(proc);  // 将进程加入就绪队列
            }
        }
        else  // 如果进程已经是就绪状态
        {
            warn("wakeup runnable process.\n");  // 输出警告信息
        }
    }
    local_intr_restore(intr_flag);  // 恢复中断状态，退出临界区
}

void schedule(void)  // 核心调度函数
{
    bool intr_flag;  // 定义中断状态标志变量
    struct proc_struct *next;  // 定义指向下一个进程的指针
    local_intr_save(intr_flag);  // 关中断并保存状态
    {
        current->need_resched = 0;  // 清除当前进程的重新调度标志
        if (current->state == PROC_RUNNABLE)  // 如果当前进程仍然是就绪状态
        {
            sched_class_enqueue(current);  // 将当前进程重新加入就绪队列
        }
        if ((next = sched_class_pick_next()) != NULL)  // 选择下一个要运行的进程
        {
            sched_class_dequeue(next);  // 将选中的进程从就绪队列移除
        }
        if (next == NULL)  // 如果没有选到任何进程（队列为空）
        {
            next = idleproc;  // 使用idle空闲进程作为下一个进程
        }
        next->runs++;  // 增加该进程的运行次数计数
        if (next != current)  // 如果选中的进程不是当前进程
        {
            proc_run(next);  // 执行进程切换，保存当前状态并加载新进程
        }
    }
    local_intr_restore(intr_flag);  // 恢复中断状态
}