#include <unistd.h>
#include <proc.h>
#include <syscall.h>
#include <trap.h>
#include <stdio.h>
#include <pmm.h>
#include <assert.h>
#include <clock.h>

static int
sys_exit(uint64_t arg[]) {
    int error_code = (int)arg[0];
    return do_exit(error_code);
}

static int
sys_fork(uint64_t arg[]) {
    struct trapframe *tf = current->tf;
    uintptr_t stack = tf->gpr.sp;
    return do_fork(0, stack, tf);
}

static int
sys_wait(uint64_t arg[]) {
    int pid = (int)arg[0];
    int *store = (int *)arg[1];
    return do_wait(pid, store);
}

static int
sys_exec(uint64_t arg[]) {
    const char *name = (const char *)arg[0];
    size_t len = (size_t)arg[1];
    unsigned char *binary = (unsigned char *)arg[2];
    size_t size = (size_t)arg[3];
    return do_execve(name, len, binary, size);
}

static int
sys_yield(uint64_t arg[]) {
    return do_yield();
}

static int
sys_kill(uint64_t arg[]) {
    int pid = (int)arg[0];
    return do_kill(pid);
}

static int
sys_getpid(uint64_t arg[]) {
    return current->pid;
}

static int
sys_putc(uint64_t arg[]) {
    int c = (int)arg[0];
    cputchar(c);
    return 0;
}

static int
sys_pgdir(uint64_t arg[]) {
    //print_pgdir();
    return 0;
}
static int sys_gettime(uint64_t arg[])  // 获取当前时间的系统调用（Lab6新增）
{
    return (int)ticks*10;  // 返回当前时钟滴答数乘以10（单位：毫秒）
}
static int sys_lab6_set_priority(uint64_t arg[])  // 设置进程优先级的系统调用（Lab6新增）
{
    uint64_t priority = (uint64_t)arg[0];  // 从参数数组中获取优先级值（第一个参数）
    lab6_set_priority(priority);  // 调用内核函数设置当前进程的优先级
    return 0;  // 返回0表示成功
}
static int (*syscalls[])(uint64_t arg[]) = {
    [SYS_exit]              sys_exit,
    [SYS_fork]              sys_fork,
    [SYS_wait]              sys_wait,
    [SYS_exec]              sys_exec,
    [SYS_yield]             sys_yield,
    [SYS_kill]              sys_kill,
    [SYS_getpid]            sys_getpid,
    [SYS_putc]              sys_putc,
    [SYS_pgdir]             sys_pgdir,
    [SYS_gettime]           sys_gettime,
    [SYS_lab6_set_priority]  sys_lab6_set_priority,
};

#define NUM_SYSCALLS        ((sizeof(syscalls)) / (sizeof(syscalls[0])))

void
syscall(void) {
    struct trapframe *tf = current->tf;
    uint64_t arg[5];
    int num = tf->gpr.a0;
    if (num >= 0 && num < NUM_SYSCALLS) {
        if (syscalls[num] != NULL) {
            arg[0] = tf->gpr.a1;
            arg[1] = tf->gpr.a2;
            arg[2] = tf->gpr.a3;
            arg[3] = tf->gpr.a4;
            arg[4] = tf->gpr.a5;
            tf->gpr.a0 = syscalls[num](arg);
            return ;
        }
    }
    print_trapframe(tf);
    panic("undefined syscall %d, pid = %d, name = %s.\n",
            num, current->pid, current->name);
}


/*
简短版（30秒）：

"Lab6在syscall.c中新增了两个系统调用。sys_gettime返回当前时钟滴答数乘以10，
单位是毫秒，用于测试程序测量运行时间。sys_lab6_set_priority接收一个优先级参数，
调用proc.c中的lab6_set_priority函数设置当前进程的优先级，用于Stride调度测试。这两个系统调用通过系统调用表注册为编号9和10。"

详细版（1分钟）：

"Lab6新增了两个系统调用来支持调度算法测试。第一个是sys_gettime，编号为9，它不需要参数，
通过读取全局变量ticks并乘以10返回系统运行的毫秒数，这个系统调用在priority测试程序中用于判断进程是否已经运行超过2秒。
第二个是sys_lab6_set_priority，编号为10，它接收一个优先级参数，从arg数组的第一个元素获取这个值，
然后调用proc.c中的lab6_set_priority函数来设置current进程的lab6_priority字段。这个系统调用让用户程序能够动态调整进程优先级，
用于测试Stride调度算法是否正确地按照优先级比例分配CPU时间。这两个系统调用都按照标准的系统调用流程实现，
通过系统调用表与对应编号关联，用户程序通过ecall指令陷入内核，内核从trapframe的寄存器中提取系统调用编号和参数，
、执行对应函数后将返回值放入a0寄存器返回用户态。"
*/