#include <defs.h>  // 包含基本定义
#include <list.h>  // 包含链表操作函数
#include <proc.h>  // 包含进程控制块定义
#include <assert.h>  // 包含断言宏
#include <default_sched.h>  // 包含调度器接口定义

// SJF调度器初始化函数
static void
SJF_init(struct run_queue *rq)  // 参数rq：指向运行队列的指针
{
    list_init(&(rq->run_list));  // 初始化运行队列的链表头，将前后指针都指向自己，形成空链表
    rq->proc_num = 0;  // 将队列中的进程数量初始化为0
}

// SJF调度器入队函数
static void
SJF_enqueue(struct run_queue *rq, struct proc_struct *proc)  // 参数：运行队列rq和要入队的进程proc
{
    assert(list_empty(&(proc->run_link)));  // 断言：检查进程的run_link节点为空（确保进程不在任何队列中）
    list_add_before(&(rq->run_list), &(proc->run_link));  // 将进程的run_link节点添加到队列链表头之前（即队尾）
    // 注意：SJF在入队时不排序，只是简单地加到队尾，排序在pick_next时进行
    proc->rq = rq;  // 设置进程的rq指针，指向它所在的运行队列
    rq->proc_num ++;  // 运行队列中的进程数量加1
}

// SJF调度器出队函数
static void
SJF_dequeue(struct run_queue *rq, struct proc_struct *proc)  // 参数：运行队列rq和要出队的进程proc
{
    assert(!list_empty(&(proc->run_link)) && proc->rq == rq);  // 断言：检查进程的run_link不为空且进程确实在这个队列中
    list_del_init(&(proc->run_link));  // 从链表中删除进程的run_link节点，并重新初始化该节点（前后指针指向自己）
    rq->proc_num --;  // 运行队列中的进程数量减1
}

// SJF调度器选择下一个进程函数（核心：遍历找最短的）
static struct proc_struct *
SJF_pick_next(struct run_queue *rq)  // 参数：运行队列rq，返回值：下一个要运行的进程指针
{
    list_entry_t *le = list_next(&(rq->run_list));  // 获取队列链表头的下一个节点（第一个进程的run_link）
    if (le == &(rq->run_list)) {  // 如果该节点就是链表头本身（说明队列为空）
        return NULL;  // 返回NULL，表示没有可运行的进程
    }

    struct proc_struct *min_proc = le2proc(le, run_link);  // 将第一个链表节点转换为进程指针，作为当前最小值的候选
    struct proc_struct *p;  // 声明临时进程指针，用于遍历
    
    // Iterate through the list to find the process with the smallest 'lab6_priority' (burst time)
    // 遍历链表，找到具有最小'lab6_priority'（执行时间）的进程
    while ((le = list_next(le)) != &(rq->run_list)) {  // 继续遍历链表，直到回到链表头（遍历完所有进程）
        p = le2proc(le, run_link);  // 将当前链表节点转换为进程指针
        if (p->lab6_priority < min_proc->lab6_priority) {  // 如果当前进程的priority小于当前最小值
            min_proc = p;  // 更新最小值为当前进程
        }
    }
    return min_proc;  // 返回priority最小的进程（执行时间最短的进程）
}

// SJF调度器时钟中断处理函数
static void
SJF_proc_tick(struct run_queue *rq, struct proc_struct *proc)  // 参数：运行队列rq和当前进程proc
{
    // SJF is non-preemptive, so we don't need to check time slice here.
    // SJF是非抢占式调度，所以我们不需要在这里检查时间片
    // The process will run until it yields or exits.
    // 进程会一直运行直到它主动让出CPU或退出
}

struct sched_class sjf_sched_class = {  // 定义SJF调度类结构体
    .name = "SJF_scheduler",  // 调度器名称为"SJF_scheduler"
    .init = SJF_init,  // 初始化函数指针指向SJF_init
    .enqueue = SJF_enqueue,  // 入队函数指针指向SJF_enqueue
    .dequeue = SJF_dequeue,  // 出队函数指针指向SJF_dequeue
    .pick_next = SJF_pick_next,  // 选择下一个进程函数指针指向SJF_pick_next（核心区别）
    .proc_tick = SJF_proc_tick,  // 时钟中断处理函数指针指向SJF_proc_tick（空函数）
};