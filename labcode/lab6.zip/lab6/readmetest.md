# 调度算法测试说明

本目录包含两个用于测试 FIFO 和 SJF 调度算法的简单测试程序：`test_fifo.c` 和 `test_sjf.c`。

## 1. 测试原理

### FIFO (First In First Out)
FIFO 调度算法按照进程进入就绪队列的顺序进行调度。
`test_fifo.c` 创建了 5 个子进程。由于它们是依次创建的，理论上它们应该按照创建顺序（0 到 4）依次执行并结束。
测试程序输出中，`Child X finished` 的顺序应该与 `Child X created` 的顺序一致。

### SJF (Shortest Job First)
SJF 调度算法优先调度执行时间最短（在 ucore lab6 中用 `lab6_priority` 模拟执行时间/burst time）的进程。
`test_sjf.c` 创建了 5 个子进程，并分别设置了不同的优先级（模拟 burst time）：
- Child 0: priority 5
- Child 1: priority 4
- Child 2: priority 3
- Child 3: priority 2
- Child 4: priority 1

每个子进程在设置优先级后会主动 `yield()` 让出 CPU。当所有子进程都进入就绪队列后，SJF 调度器应该选择 priority 最小的进程先执行。
预期结果是：Child 4 最先执行完成，Child 0 最后执行完成。

## 2. 如何运行测试

### 步骤 1: 修改调度器配置
在 `kern/schedule/sched.c` 中，修改 `sched_init` 函数，选择相应的调度类。

**测试 FIFO:**
```c
// kern/schedule/sched.c
void sched_init(void) {
    // ...
    sched_class = &fifo_sched_class; // 确保这里使用 FIFO 调度器
    // ...
}
```
(注意：你需要确保 `fifo_sched_class` 已定义并导出，通常在 `default_sched_fifo.c` 中定义，并在 `default_sched.h` 或 `sched.c` 中声明)

**测试 SJF:**
```c
// kern/schedule/sched.c
void sched_init(void) {
    // ...
    sched_class = &sjf_sched_class; // 确保这里使用 SJF 调度器
    // ...
}
```

### 步骤 2: 修改初始执行程序
在 `kern/process/proc.c` 中，修改 `user_main` 函数，使其执行对应的测试程序。

**测试 FIFO:**
```c
// kern/process/proc.c
static int user_main(void *arg) {
    // ...
    KERNEL_EXECVE(test_fifo); // 修改为 test_fifo
    // ...
}
```

**测试 SJF:**
```c
// kern/process/proc.c
static int user_main(void *arg) {
    // ...
    KERNEL_EXECVE(test_sjf); // 修改为 test_sjf
    // ...
}
```

### 步骤 3: 编译并运行
在终端中运行：
```bash
make qemu
```

观察输出结果验证调度算法的正确性。

## 3. 预期输出示例

**FIFO:**
```
FIFO Test Started
Child 0 created
Child 1 created
Child 2 created
Child 3 created
Child 4 created
Parent waiting for children...
Child 0 finished
Child 1 finished
Child 2 finished
Child 3 finished
Child 4 finished
FIFO Test Finished
```

**SJF:**
```
SJF Test Started
Child 0 created with priority 5
Child 1 created with priority 4
Child 2 created with priority 3
Child 3 created with priority 2
Child 4 created with priority 1
Parent waiting for children...
Child 4 executing
Child 4 finished
Child 3 executing
Child 3 finished
Child 2 executing
Child 2 finished
Child 1 executing
Child 1 finished
Child 0 executing
Child 0 finished
SJF Test Finished
```
(注意：具体的输出顺序可能会受到父进程何时让出 CPU 的影响，但核心是观察 `finished` 的顺序)
