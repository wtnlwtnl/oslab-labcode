# Lab 5 与 Lab 6 关键函数对比分析

## 问题

比较一个在 Lab 5 和 Lab 6 都有，但实现不同的函数，说说为什么要做这个改动，不做这个改动会出什么问题。

---

## 一、`schedule()` 函数对比

### Lab 5 实现（硬编码遍历）

```c
void schedule(void) {
    list_entry_t *le, *last;
    struct proc_struct *next = NULL;
    local_intr_save(intr_flag);
    {
        current->need_resched = 0;
        // ★ 直接遍历 proc_list 链表（所有进程的链表）
        last = (current == idleproc) ? &proc_list : &(current->list_link);
        le = last;
        do {
            if ((le = list_next(le)) != &proc_list) {
                next = le2proc(le, list_link);
                if (next->state == PROC_RUNNABLE) {  // 找到第一个就绪的
                    break;
                }
            }
        } while (le != last);
        // ...
        proc_run(next);
    }
}
```

### Lab 6 实现（面向接口）

```c
void schedule(void) {
    struct proc_struct *next;
    local_intr_save(intr_flag);
    {
        current->need_resched = 0;
        if (current->state == PROC_RUNNABLE) {
            sched_class_enqueue(current);    // ★ 调用接口入队
        }
        if ((next = sched_class_pick_next()) != NULL) {  // ★ 调用接口选择
            sched_class_dequeue(next);       // ★ 调用接口出队
        }
        if (next == NULL) {
            next = idleproc;
        }
        // ...
        proc_run(next);
    }
}
```

### 对比表

| 方面 | Lab 5 | Lab 6 |
|------|-------|-------|
| 选择方式 | `do-while` 遍历 `proc_list` | 调用 `sched_class->pick_next()` |
| 数据结构 | 固定使用全局进程链表 | 使用独立的运行队列 `run_queue` |
| 算法 | 硬编码（简单轮询） | 可插拔（RR/Stride/FIFO 等） |
| 扩展性 | 差，改算法要重写函数 | 好，只需实现新的 `sched_class` |

---

## 二、`wakeup_proc()` 函数对比

### Lab 5 实现

```c
void wakeup_proc(struct proc_struct *proc) {
    if (proc->state != PROC_RUNNABLE) {
        proc->state = PROC_RUNNABLE;  // 仅修改状态
        proc->wait_state = 0;
    }
}
```

### Lab 6 实现

```c
void wakeup_proc(struct proc_struct *proc) {
    if (proc->state != PROC_RUNNABLE) {
        proc->state = PROC_RUNNABLE;
        proc->wait_state = 0;
        if (proc != current) {
            sched_class_enqueue(proc);  // ★ 新增：显式入队
        }
    }
}
```

### 关键差异

| Lab 5 | Lab 6 |
|-------|-------|
| 只修改状态为 `RUNNABLE` | 修改状态 + **显式调用 `enqueue` 入队** |

---

## 三、为什么要做这个改动？

### 1. Lab 5 的设计

Lab 5 的 `schedule()` **遍历所有进程的链表 (`proc_list`)**：

```c
do {
    next = le2proc(le, list_link);
    if (next->state == PROC_RUNNABLE) break;  // 只看状态
} while (le != last);
```

- **没有独立的就绪队列**：所有进程（就绪、睡眠、僵尸）都在同一个链表
- **调度靠状态判断**：遍历时检查 `state == PROC_RUNNABLE`
- **所以 `wakeup_proc` 只需改状态**：改了状态，`schedule` 遍历时自然能找到

### 2. Lab 6 的改进

Lab 6 引入了**独立的运行队列 (`run_queue`)**，只存放就绪进程：

```c
next = sched_class_pick_next();  // 只从运行队列选
```

- **有独立的就绪队列**：与全局进程链表分离
- **调度靠队列**：只从运行队列里选择
- **所以必须显式入队**：不入队就不在运行队列里，就选不到

---

## 四、不做这个改动会出什么问题？

### 问题 1：如果 Lab 6 的 `wakeup_proc` 不调用 `enqueue`

```c
// 错误的实现：不入队
void wakeup_proc(struct proc_struct *proc) {
    proc->state = PROC_RUNNABLE;  // 只改状态
    // 没有 sched_class_enqueue(proc) ！
}
```

**后果：进程永远不会被调度！**

```
fork() 创建子进程
    ↓
wakeup_proc(子进程)  →  状态改成 RUNNABLE，但不在运行队列里
    ↓
schedule() → pick_next()  →  从运行队列选择
    ↓
运行队列是空的！子进程不在里面！
    ↓
★ 子进程永远不会运行 → 系统卡死或功能异常
```

### 问题 2：如果 Lab 6 的 `schedule` 仍用 Lab 5 的遍历方式

```c
// 错误的实现：还是遍历 proc_list
do {
    next = le2proc(le, list_link);
    if (next->state == PROC_RUNNABLE) break;
} while (le != last);
```

**后果：调度框架失效！**

- Stride 调度需要选 stride 值最小的进程，遍历只能找"第一个就绪的"
- `enqueue/dequeue` 维护的运行队列没人用，白维护了
- 无法实现优先级调度、公平调度等高级算法

---

## 五、改动的本质：从"状态驱动"到"队列驱动"

```
┌─────────────────────────────────────────────────────────────┐
│                        Lab 5                                │
│                                                             │
│   proc_list: [P1] ↔ [P2] ↔ [P3] ↔ [P4] ↔ ...              │
│              状态    状态    状态    状态                     │
│             SLEEP  RUNNABLE ZOMBIE RUNNABLE                 │
│                                                             │
│   schedule: 遍历整个链表，找 state == RUNNABLE 的           │
└─────────────────────────────────────────────────────────────┘

                           ↓ 改进

┌─────────────────────────────────────────────────────────────┐
│                        Lab 6                                │
│                                                             │
│   proc_list: [P1] ↔ [P2] ↔ [P3] ↔ [P4] ↔ ...  （全部进程） │
│                                                             │
│   run_queue: [P2] ↔ [P4]  （只有就绪进程）                  │
│                                                             │
│   schedule: 只看 run_queue，调用 pick_next() 选择           │
└─────────────────────────────────────────────────────────────┘
```

---

## 六、答辩精简版

**问题：比较 Lab 5 和 Lab 6 中 `schedule()`/`wakeup_proc()` 的改动，为什么要改？不改会怎样？**

### 改动内容：

- **`wakeup_proc`**：Lab 6 新增了 `sched_class_enqueue(proc)` 调用
- **`schedule`**：Lab 6 用 `enqueue/pick_next/dequeue` 接口替代了遍历 `proc_list`

### 为什么要改：

- Lab 5 没有独立的运行队列，调度时遍历所有进程，**效率低且无法扩展**
- Lab 6 引入了运行队列和调度类框架，需要**显式维护队列**

### 不改的后果：

- 如果 `wakeup_proc` 不 `enqueue`：新创建/唤醒的进程不在运行队列里，**永远不会被调度，系统卡死**
- 如果 `schedule` 还用遍历：Stride 等优先级算法无法实现，**调度框架失效**

### 一句话总结：

Lab 5 是"状态驱动"调度（遍历找状态），Lab 6 是"队列驱动"调度（从队列选择），所以必须显式维护运行队列。
