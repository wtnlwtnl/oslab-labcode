# 调度类的初始化流程分析

## 问题

描述从内核启动到调度器初始化完成的完整流程，分析 `default_sched_class` 如何与调度器框架关联。

---

## 一、完整的启动流程图

```
┌─────────────────────────────────────────────────────────────────────┐
│  OpenSBI/BootLoader 加载内核到内存，跳转到 kern_entry               │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│  kern_entry (entry.S)                                               │
│  ├─ 设置 satp 寄存器，开启 Sv39 分页                                 │
│  ├─ 设置内核栈指针 sp                                                │
│  └─ jr kern_init  跳转到 C 语言入口                                  │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│  kern_init (init.c)                                                 │
│  ├─ cons_init()    控制台初始化                                      │
│  ├─ pmm_init()     物理内存管理初始化                                │
│  ├─ vmm_init()     虚拟内存管理初始化                                │
│  ├─ sched_init()   ★ 调度器初始化 ★                                 │
│  ├─ proc_init()    进程子系统初始化（创建 idle 和 init 进程）        │
│  ├─ clock_init()   时钟中断初始化                                    │
│  └─ cpu_idle()     进入空闲循环，触发首次调度                        │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 二、`sched_init` 详细分析

在 `kern/init/init.c` 第40行调用 `sched_init()`：

```c
// kern/init/init.c 第40行
sched_init();
```

`sched_init` 的实现在 `kern/schedule/sched.c` 第53-64行：

```c
void sched_init(void)
{
    list_init(&timer_list);                    // ① 初始化定时器链表
    
    sched_class = &default_sched_class;        // ② 【核心】绑定调度算法
    
    rq = &__rq;                                // ③ 设置全局运行队列指针
    rq->max_time_slice = MAX_TIME_SLICE;       // ④ 设置最大时间片为5
    sched_class->init(rq);                     // ⑤ 调用具体算法的初始化函数
    
    cprintf("sched class: %s\n", sched_class->name);  // 打印调度器名称
}
```

### 逐行解析

| 步骤 | 代码 | 作用 |
|------|------|------|
| ① | `list_init(&timer_list)` | 初始化定时器链表（为sleep等功能预留） |
| ② | `sched_class = &default_sched_class` | **关键绑定点**：将全局调度类指针指向具体实现 |
| ③ | `rq = &__rq` | 让运行队列指针指向全局静态变量 `__rq` |
| ④ | `rq->max_time_slice = MAX_TIME_SLICE` | 设置时间片上限为5个tick |
| ⑤ | `sched_class->init(rq)` | **多态调用**：调用具体算法的初始化函数 |

---

## 三、`default_sched_class` 如何与框架关联

### 3.1 接口定义（kern/schedule/sched.h）

```c
struct sched_class {
    const char *name;                                              // 调度器名称
    void (*init)(struct run_queue *rq);                            // 初始化
    void (*enqueue)(struct run_queue *rq, struct proc_struct *p);  // 入队
    void (*dequeue)(struct run_queue *rq, struct proc_struct *p);  // 出队
    struct proc_struct *(*pick_next)(struct run_queue *rq);        // 选择下一个
    void (*proc_tick)(struct run_queue *rq, struct proc_struct *p);// 时钟处理
};
```

这是一个**函数指针表**，类似于 C++ 中的虚函数表（vtable），实现了 C 语言的多态机制。

### 3.2 接口实现（kern/schedule/default_sched.c）

```c
struct sched_class default_sched_class = {
    .name = "RR_scheduler",      // 名称：Round Robin
    .init = RR_init,             // 指向 RR_init 函数
    .enqueue = RR_enqueue,       // 指向 RR_enqueue 函数
    .dequeue = RR_dequeue,       // 指向 RR_dequeue 函数
    .pick_next = RR_pick_next,   // 指向 RR_pick_next 函数
    .proc_tick = RR_proc_tick,   // 指向 RR_proc_tick 函数
};
```

### 3.3 声明与导出（kern/schedule/default_sched.h）

```c
extern struct sched_class default_sched_class;   // RR调度器
extern struct sched_class stride_sched_class;    // Stride调度器
extern struct sched_class fifo_sched_class;      // FIFO调度器
extern struct sched_class sjf_sched_class;       // SJF调度器
```

---

## 四、关联流程示意图

```
                        ┌──────────────────────────────────┐
                        │       sched.h (接口定义)         │
                        │  struct sched_class { ... }      │
                        └──────────────────────────────────┘
                                       ▲
                                       │ 实现接口
          ┌────────────────────────────┼────────────────────────────┐
          │                            │                            │
          ▼                            ▼                            ▼
┌──────────────────┐      ┌──────────────────┐      ┌──────────────────┐
│ default_sched.c  │      │ default_sched_   │      │ default_sched_   │
│ (RR调度器)       │      │ stride.c         │      │ sjf.c            │
│                  │      │ (Stride调度器)   │      │ (SJF调度器)      │
│ default_sched_   │      │ stride_sched_    │      │ sjf_sched_       │
│ class            │      │ class            │      │ class            │
└──────────────────┘      └──────────────────┘      └──────────────────┘
          │
          │ sched_class = &default_sched_class
          ▼
┌──────────────────────────────────────────────────────────────────────┐
│                         sched.c (调度框架)                           │
│  static struct sched_class *sched_class;  ← 全局指针                 │
│                                                                      │
│  sched_init() {                                                      │
│      sched_class = &default_sched_class;  // 绑定具体实现            │
│      sched_class->init(rq);               // 多态调用                │
│  }                                                                   │
│                                                                      │
│  schedule() {                                                        │
│      sched_class->enqueue(...)            // 多态调用                │
│      sched_class->pick_next(...)          // 多态调用                │
│  }                                                                   │
└──────────────────────────────────────────────────────────────────────┘
```

---

## 五、答辩话术总结

### 从内核启动到调度器初始化完成的流程：

1. **BootLoader** 加载内核到内存，跳转到汇编入口 `kern_entry`。
2. **entry.S** 设置页表、开启 Sv39 分页、设置内核栈，然后跳转到 C 语言入口 `kern_init`。
3. **kern_init** 依次初始化各子系统，在 `proc_init`（进程子系统）之前调用 `sched_init`（调度子系统）。
4. **sched_init** 做了三件关键事情：
   - 将全局指针 `sched_class` 指向具体的调度算法实现（如 `default_sched_class`）；
   - 初始化全局运行队列 `rq`；
   - 通过 `sched_class->init(rq)` 多态调用具体算法的初始化函数。

### `default_sched_class` 与框架的关联方式：

- `sched_class` 结构体定义了统一的接口（5个函数指针），这是一种**策略模式**；
- `default_sched_class` 是该接口的一个具体实现，用 C 语言的**结构体初始化**语法将 RR 算法的各个函数绑定到对应的函数指针上；
- 在 `sched_init` 中，通过一行赋值 `sched_class = &default_sched_class` 完成绑定；
- 之后框架代码（如 `schedule`、`wakeup_proc`）通过 `sched_class->xxx()` 进行**多态调用**，无需关心具体是哪种算法。

### 这种设计的意义：

实现了**机制与策略的分离**——框架负责调度的流程控制（机制），具体算法负责决定谁先运行（策略），更换调度算法只需修改一行指针赋值。
